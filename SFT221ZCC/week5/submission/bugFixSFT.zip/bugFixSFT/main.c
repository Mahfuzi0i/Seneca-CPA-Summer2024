#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "stringhelp.h"
#include <string.h>
#include <ctype.h>

int main(void)
{
    char testStr[] = { "This is the 3453 final test \n with    multiple @@@ 3454 values with MIxxed types 12444 an\n multiple line     s and hoard of 12343 ((&*( special chracters. FINALLY !! \n It works 45433 just 5545 fine."};
    struct StringIndex index = indexString(testStr);
    int i;
    printf("LINES\n");
    for (i = 0; i < index.numLines; i++)
    {
        printUntil(index.str, index.lineStarts[i], '\n');
        printf("\n");
    }
    printf("\nWORDS\n");
    for (i = 0; i < index.numWords; i++)
    {
        printUntilSpace(index.str, index.wordStarts[i]);
        printf("\n");
    }
    printf("\nNUMBERS\n");
    for (i = 0; i < index.numNumbers; i++)
    {
        printUntilSpace(index.str, index.numberStarts[i]);
        printf("\n");
    }
    return 0;
}
